"""					TANKS STORY MODE

	
1.It is the launch day of an AR(Augmented Reality) game that issuing to revolutionise the gaming industry. It is called’ TANK WARS’. The only requirement to play that game is Wi-fi and electricity which will power the headgear(HELLECTRICITY aka HELO) used to play this game which the players will have to buy. It costs only $200 so the gear is expected to sell out.

2.The expectation was met . 2,000,000 copies gears were sold on the first day.The players entered the game as soon as they got home and you are one of  them . 



____User creates a tank____



3.They were allowed to build their own characters which were TANKS. All the tanks were made within an hour of the release.  2 million  people  entered  the game  together and gathered around the Town Hall where the instructions were given.



 4.(To be  made in a canvas)
Instructions:(To be  named  1,2, 4…..)
 4.1)There are 100 levels in this game
 4.2)Each floor represents a level , so  there are 100 floors  for  battle.
 4. 4)There is also a safe zone where players can’t be  attacked.That is this place , the Town Hall or the 0th floor.
 4.4)So there are  101  floors  in total  and each floor has it’s own  theme so some powers are stronger than usual in battle zones  and  some are weaker.
 4.5)To make the game harder , the weaker and stronger things will usually be the ones usually paired up together like  one-hand sword and shield of the  same material.
 4.6)To  cross a level , the player must beat the boss  of that particular level. It may be done solo or in guilds.
 4.7)Guilds are initiated by two members (the leaders) who can  then add other  members with their  consent.(maximum number  of people is 15)
This can be  done by the Create Guild option on the top right  of your imaginary screen.This button will change to Invite To Guild after you are in a guild  and a new button will  be introduced , Leave Guild  that makes you leave  a guild.
 4.8)The advantage of using the guild option and not just making unofficial groups are that :
	 4.8.1)Members will be notified about mishaps, celebrations , opportunities etc(Setting 		depend on the  leaders)
	 4.8.2)There is a hierarchy so the  loot from the boss is divided in set ratios and it is automatically added to there accounts of the  players.
	 4.8. 4)The boss slayer gets an ability at the end of the level(going to the upper  floor), and this is given to all members of the  guild along with levelling up.
	 4.8.4)The two leaders have equal powers but a decision cannot be taken without the approval of both of them so it prevents betrayal.
	 4.8.5)Stronger the guild rating , the less weaker  your tools become which are against the theme of the tier.
	 4.8.6)If there is  an ambush(threatened if he declines  proposal) on a player who is alone but a part  of  a  guild, he is allowed to have other people fight for him(fro his guild) in proposed  duels(will be explained  later)
	 4.8.7)Other advantages will  be understood by the players with experience
 4.9)Duels are  proposed by  a player who wants to challenge another player  for an ability or gold.
If the challenger loses , he loses something of equal value which is pre-decided by the challenger.
 4.10)Other rules have to  be  understood  by the  players their own through observations.


5.Task1-Meet other  players and form a guild.
____User forms a guild____



6.Task2-Invite a person to the guild



____User  invites a person  to the guild____



7.Invite  other  players  if  you like(highly recommended) and click READY when you are  done!!


____User widens the  guild and clicks  READY____


8.BRAKKADOOMM!!!!!
It  is  the  projection of the creator of the game!!!!
It is none other than  Muhammad Swami Dave Singh !!!!!
He says:
“It  is a pleasure meeting all the buyers of my  wonderful creation!! I cannot   thank you enough ,  so my gift to  all of you  is extra 100 MaxoGold in your accounts because  you are  the first ones to ever play the game (aside: after the  BETA testers of course). You are probably wondering  what MaxoGold  is. I’ll tell you . It is a currency you can use anywhere in this game!! Some jobs will require  particular form of  payment and if you can’t provide  that , you can use this currency. The conversion rate is a  100  times ,  so 100 MaxoGold is worth 100,000 normal gold!! The advantage of using  MaxoGold is that the seller cannot refuse payment in terms of MaxoGold. If he  does ,  he’ll  die, not just here……”

9. “but in  the  real world as well.Yess!!! This game is  to kill all the  weaklings  on this  planet.   Your family  doesn’t know  this yet but they  will be told!! If you die  in this game  , you die in real life. Wondering how  that  is possible?? I’ll tell you!! Your  Helos will  electrocute you. They aren’t  called Hellectricity  for no reason. Muahhhaahaa!!.”

10. “If  any  person  removes  the  HELO  from  your head, they get electrocuted  and  they die along   with you!!!!.  If  they turn off  the power  , the extra battery in the Helo will do the  job!!If you want  to make it out alive, you have to complete all the levels  in this  game and defeat the ULTRA   BOSS who’s powers are  the sums of  the individual powers of the  bosses  from level  1 through 100!!!”

11. “You will be allowed  to change or leave your present guilds  once  you complete  level 1!!”(which is why it  was highly recommended)





12.________STORY BEGINS________

"""
